
###################################################################################################################################
#Accuracy versus repetibility (variability) ellipse analysis variation
######################################################################################################################################

# este metodo se basa en distancias estadisticas y es multivariante.

#ver en: http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/betadisper.html
#implementar este metodo que tambien es interesante

#Multivariate homogeneity of groups dispersions (variances)
#Description
#Implements Marti Anderson's PERMDISP2 procedure for the analysis of multivariate homogeneity of group dispersions (variances).


#' Accuracy versus fiability (variability) ellipse analysis variation for a factor level analysis.
#' @param Y response variable
#' @param factor_a vector with levels of factor where variability-accuracy between levels is analyzed
#' @param eel.plot type of ellipse (normal eel.plot="Norma", or t-Hotelling multivariate, eel.plot="tHotelling")
#' @return plots accuracy-variability analysis, description
#' @export
#'
#' @examples
#'
#' #####################
#' #FIRST EXAMPLE
#' #####################
#'
#' #Simulate an experiment with a batch factor (3 bathes: different variances) and 3 variables
#' Batches.simulated <- data.frame(Bat = c(rep("B1",5),rep("B2",5),rep("B3",5),rep("B4",5),rep("B5",5)),
#'                                           var1 = c(rnorm(5,55,15), rnorm(5,55,14), rnorm(5,55,4),rnorm(5,55,4),rnorm(5,55,4)))
#'
#' #Variability analysis between levels of the factor (ex: batch factor)
#' Miriam.analysis.ellipse(Y=Batches.simulated[,2],factor_a=Batches.simulated$Bat, eel.plot="tHotelling")
#'

Miriam.analysis.ellipse <- function(Y,factor_a, eel.plot="tHotelling"){


  #crea unas elipses de confianza alrededor de los puntos
  ztot<- data.frame(Y,factor_a)
  #sumarize
  library(Rmisc)
  res.Q1 <- summarySE(ztot, measurevar="Y", groupvars=c("factor_a"),na.rm = T)
  res.Q1
  #summary od data
  print("Summary of data------------------------------------------")
  print(res.Q1)
  library(gplots)
  plotmeans(Y~ factor_a, data=ztot, frame = T,xlab = "factor levels", ylab="Y", main="Mean plot with CI95%")

  #sumarize
  library(car)
  min.x<-min(c(res.Q1$Y))
  max.x<-max(c(res.Q1$Y))
  min.y<-min(c(res.Q1$sd))
  max.y<-max(c(res.Q1$sd))
  #dataEllipse(x=c(res.Q1$Y), y=c(res.Q1$sd), levels=c(0.05,  0.25, 0.5, 0.75, 0.95, 0.99),
  #            xlab="Mean (Accuracy)", ylab="Sd (Variability, repeatibility)",
  #            robust = T,
  #            main="Ellipse plot (CAR) with CI%(5,25,50,75,95,99)",
  #            xlim=c(min.x*0.8,max.x*1.2),ylim=c(min.y*0.8,max.y*1.2),center.pch = F,
  #            ellipse.label = c("0.05", "0.25", "0.5", "0.75", "0.95", "0.99"))
  #text(c(res.Q1$Y), c(res.Q1$sd),labels=(res.Q1$factor_a), cex= 1,adj = 1.2,col = "red")

  #John Fox and Sanford Weisberg (2011). An R Companion to Applied Regression, Second Edition. Thousand Oaks CA: Sage. URL: http://socserv.socsci.mcmaster.ca/jfox/Books/Companion
  #aesthetic mapping
  library(ggplot2)
  library(ggrepel)


  #grafico con distribucion T hotelling


  #grafico con distribucion normal
  if(eel.plot=="Norma"){
    nbaplot_t<-ggplot(res.Q1, aes(c(res.Q1$Y), c(res.Q1$sd),col="CI%") ) +
      geom_point(color = "blue", size = 3) +
      stat_ellipse(type = "norm", linetype = 2, level=0.05) +
      stat_ellipse(type = "norm", linetype = 2, level=0.25) +
      stat_ellipse(type = "norm", linetype = 2, level=0.5, color="blue") +
      stat_ellipse(type = "norm", linetype = 2, level=0.75) +
      stat_ellipse(type = "norm", linetype = 2, level=0.95) +
      stat_ellipse(type = "norm", linetype = 2, level=0.99)
    print(nbaplot_t + geom_label_repel(aes(label = res.Q1$factor_a),
                                       box.padding   = 0.35,
                                       point.padding = 0.5,
                                       segment.color = 'grey50') +    theme_classic() +
            scale_x_continuous(name="Mean (Accuracy") +
            scale_y_continuous(name="Sd (variability, repetatibility") +
            ggtitle("Aesthetic mapping Normal distribution with CI%(5,25,50,75,95,99)"))
  }

  if(eel.plot=="tHotelling"){
    nbaplot_t<-ggplot(res.Q1, aes(c(res.Q1$Y), c(res.Q1$sd),col="CI%") ) +
      geom_point(color = "blue", size = 3) +
      stat_ellipse(type = "t", linetype = 2, level=0.05) +
      stat_ellipse(type = "t", linetype = 2, level=0.25) +
      stat_ellipse(type = "t", linetype = 2, level=0.5, color="blue") +
      stat_ellipse(type = "t", linetype = 2, level=0.75) +
      stat_ellipse(type = "t", linetype = 2, level=0.95) +
      stat_ellipse(type = "t", linetype = 2, level=0.99)


    print(nbaplot_t + geom_label_repel(aes(label = res.Q1$factor_a),
                                       box.padding   = 0.35,
                                       point.padding = 0.5,
                                       segment.color = 'grey50') +    theme_classic() +
            scale_x_continuous(name="Mean (Accuracy") +
            scale_y_continuous(name="Sd (variability, repetatibility") +
            ggtitle("Aesthetic mapping t multivariate distribution with CI%(5,25,50,75,95,99)"))

  }


  #I've had a bit more time to look into it. stat_ellipse() draws a data ellipse. The code is borrowed from the car library. It does not look very difficult to extend stat_ellipse() to draw confidence ellipses. Below I edited stat-ellipse.R to accept a formula to pass linear models and to accept type=confidence in addition to the other three types. The ellipses are produced, but don't look right. I was about to give up when I noticed Claus's message. I decided to post my efforts below and hope someone can take it the extra step.
  #hace un analisis de los niveles del factor, como si estos fueron niveles aleatorios y hace tambien un ANOVA
  RES.AOV<-aov(Y~ factor_a, data=ztot)
  print(summary(RES.AOV))
  anov<-summary(RES.AOV)
  #str(anov)
  n<-(anov[[1]][[1]][2] + anov[[1]][[1]][1] + 1)/(anov[[1]][[1]][1]+1)

  #Reproductibility variance, σR^2
  #Repeatability variance, σr^2
  #Between-laboratory variance, σB^2
  MSB<-anov[[1]][[3]][1]
  MSR<-anov[[1]][[3]][2]
  var_R<-MSR
  var_B<-(MSB - MSR)/n
  if(var_B<0){var_B<-0}
  var_Y<-var_R+var_B
  print("Variances estimated in the ANOVA model: Random factor A")
  cat("Reproductibility variance, sigma2_Y2= ",var_Y,sep="",fill = T)
  cat("Repeatability variance, sigma2_r= ",var_R,sep="",fill = T)
  cat("Between-laboratory variance, sigma2_B= ",var_B,sep="",fill = T)


  #remove batch effect: https://www.biorxiv.org/content/10.1101/669739v1
  #remove batch effects: https://rdrr.io/bioc/sva/
  #exploBATCH
  #require(devtools)
  #install_github("syspremed/exploBATCH")
}


