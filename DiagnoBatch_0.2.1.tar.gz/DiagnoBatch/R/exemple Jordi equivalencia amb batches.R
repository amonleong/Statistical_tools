#exemple analisis Jordi Ocanya

ejemplo_diclofenac_Kern<- function(){
  #DATOS DICLOFENAC#######################################################
  # Both input options are valid:
  # Text data:
  diclofenac <- read.table("diclofenac_data.txt", header = TRUE)
  # Binary data:
  load("diclofenac_data.rda")
  #View los datos
  View(diclofenac)
  summary(diclofenac)



  # Total number of observations:
  N <- nrow(diclofenac)

  diclofenac$ST <- abs(diclofenac$ST)
  diclofenac$SRperc <- abs(diclofenac$SRperc)

  # summaryAnalysis("SA", data = diclofenac)

  # summaryAnalysis("SB", data = diclofenac)

  # summaryAnalysis("ST", data = diclofenac)

  summaryAnalysis("SRperc", data = diclofenac)

  summaryAnalysis("ZeroShearVisc", data = diclofenac)

  # summaryAnalysis("ZeroShearViscEE", data = diclofenac)

  summaryAnalysis("CriticalShear", data = diclofenac)

  # summaryAnalysis("CriticalShearEE", data = diclofenac)

  summaryAnalysis("YieldStress", data = diclofenac)

  summaryAnalysis("Viscosity", data = diclofenac)

  summaryAnalysis("ElasticMod", data = diclofenac)

  summaryAnalysis("ViscMod", data = diclofenac)      # Possible outlier

  summaryAnalysis("TanDelta", data = diclofenac)     # BE with 0.9/1.11 limits

  summaryAnalysis("J0", data = diclofenac)

  summaryAnalysis("MaxwellDV", data = diclofenac)
  #
  # summaryAnalysis("Jmax", data = diclofenac)
  #
  # summaryAnalysis("Jmin", data = diclofenac)

  summaryAnalysis("Rperc", data = diclofenac)        # BE with 0.9/1.11 limits

  # summaryAnalysis("pH", data = diclofenac)           # BE with 0.9/1.11 limits
  #
  # summaryAnalysis("Conductivity", data = diclofenac) # BE with 0.8/1.25 limits (not 0.9/1.11)
  # (but heteroscedasticity and non normality)

  # *******************************************************************************************
  #                              Rheology global analysis
  # *******************************************************************************************

  rheologyVars <- c("SRperc", "ZeroShearVisc", "CriticalShear", "YieldStress",
                    "Viscosity", "ElasticMod", "ViscMod", "TanDelta",
                    "J0", "MaxwellDV", "Rperc")
  # In ketoconazol protocol, "MaxwellDV" (Maxwell dashpot viscosity, \eta_0^c)
  # is defined as 'Residual viscosity in creep' (also using the symbol \eta_0^c)

  rheologyNumVars <- length(rheologyVars)
  logRheologyVars <- paste("log", rheologyVars, sep = "")
  rheology <- diclofenac[, rheologyVars]
  logRheology <- log(rheology)
  colnames(logRheology) <- logRheologyVars

  # *******************************************************************************************
  #              EXPLORING THE SUITABILITY OF THE FIRST PRINCIPAL COMPONENT
  #         AS AN ADEQUATE SUMMARY - REPRESENTATIVE OF THE RHEOLOGY VARIABLES
  # *******************************************************************************************

  # Function returning the variances and cummulative variances of principal components:
  varPrComps <- function(prcomp.object) {
    var.pc <- prcomp.object$sdev * prcomp.object$sdev
    cumVar.pc <- cumsum(var.pc)
    pcEigen <- matrix(round(c(prcomp.object$sdev,
                              var.pc,
                              cumVar.pc,
                              cumVar.pc / cumVar.pc[length(cumVar.pc)] * 100), digits = 2),
                      nrow = 4, byrow = TRUE)
    rownames(pcEigen) <- c("standard dev.", "variance", "cummulative var.", "% cumm. var.")
    colnames(pcEigen) <- paste0("PC", 1:length(var.pc))
    pcEigen

  }

  # *******************************************************************************************
  #               PCA in logarithmic scale (log transformed rheology variables)
  #                                       and
  #        standarizing these log transformed variables (using their correlations matrix):
  # *******************************************************************************************
  # rheology.pca <- prcomp(~ log(SRperc) + log(ZeroShearVisc) + log(CriticalShear) +
  #                          log(YieldStress) + log(Viscosity) + log(ElasticMod) +
  #                          log(ViscMod) + log(TanDelta) + log(J0) + log(Rperc),
  #                        data = diclofenac, scale. = TRUE, retx = TRUE)
  rheology.pca <- prcomp(as.formula(paste0("~ ", paste0(logRheologyVars, collapse = " + "))),
                         data = logRheology, scale. = TRUE, retx = TRUE)
  rheology.pca

  # First principal component values for each one of the 30 experiments:
  PC1 <- rheology.pca$x[,1]

  # Eigen values:
  vPC <- varPrComps(rheology.pca)
  vPC

  windows(21,21)

  # Exploring the first principal component, PC1, as a candidate for rheology variables
  # representative summary:
  plot(rheology.pca$x, type = "n")
  text(rheology.pca$x, labels = diclofenac$Form, col = ifelse(diclofenac$Form == "Voltadol", "blue", "red"))

  # Biplot: how principal components relate with variables?
  # Joint graphical representation of rheology points in the principal components space
  # and rheology variables:
  biplot(rheology.pca, scale = 0)
  # Temptative conclusion:
  # PC1 seems mainly related to distinguishing between both forms (Kern and Voltadol)
  # while PC2 is not.
  # 8 rheology variables:
  # "SRperc", "YieldStress", "Viscosity", "ElasticMod", "ViscMod", "TanDelta", "J0"
  # and "MaxwellDV",
  # mainly characterise first principal component PC1 (and so form differences), with
  # similar weight, but with "J0" in opposition to the other 7 (high values of it
  # characterise Voltadol while high values of the remaining characterise Kern).
  # Among these 8 variables characterising PC1 and then form differences, the most
  # intensely related to PC1 (their arrow is maximally parallel to PC1 in the biplot)
  # are "ViscMod", "MaxwellDV" and (slightly less) "Viscosity".
  #
  # On the other hand, variables "CriticalShear" and "ZeroShearVisc"
  # (and to a lesser extent "Rperc", which in fact is related -with small influence-
  # with both principal components) characterise the second principal component,
  # so they are'nt very related to differences between Voltadol and Kern (but probably
  # may express an interesting second rheology dimension?).
  # Use only the first group of variables in bioequivalence studies??

  # Possibly, from the point of view of bioequivalence study, this principal component
  # analysis inflates variances in a great extent: the variances of each rheology variable,
  # at log scale, are:
  var.rheoVars <- apply(logRheology, 2, var)
  var.rheoVars
  # adding up to:
  sum(var.rheoVars)
  # while this principal components analysis scales all variables to have
  # unit variance, adding up to:
  vPC["cummulative var.",ncol(vPC)]
  # # A conservative, very moderate, rescaling would be to make the variance of
  # # the first principal component PC1 equal to the greater variance among the
  # # initial (log) variables:
  # PCs <- (rheology.pca$x / rheology.pca$sdev[1]) * sqrt(max(var.rheoVars))
  # var(PCs[,1])
  # var(PCs[,2])
  # plot(PCs, type = "n")
  # text(PCs, labels = diclofenac$Form, col = ifelse(diclofenac$Form == "Voltadol", "blue", "red"))

  # PC1 <- (PC1 / sd(PC1)) * sqrt(sum(rheology.pca$rotation[,1] * rheology.pca$rotation[,1] * var.rheoVars))
  rotat2 <- rheology.pca$rotation * rheology.pca$rotation
  PCs <- (rheology.pca$x / matrix(rheology.pca$sdev, ncol = rheologyNumVars, nrow = N, byrow = TRUE)) *
    sqrt(matrix(var.rheoVars %*% rotat2, ncol = rheologyNumVars, nrow = N, byrow = TRUE))

  # Principal components at original scale:
  pcs <- exp(PCs)
  plot(pcs, type = "n")
  text(pcs, labels = diclofenac$Form, col = ifelse(diclofenac$Form == "Voltadol", "blue", "red"))

  # First principal component at original scale:
  pcs[,1]

  mpc1 <- tapply(PCs[,1], diclofenac$Form, mean)
  # Difference of means at logarithmic scale:
  dm <- mpc1["Kern"] - mpc1["Voltadol"]
  names(dm) <- "Means difference at log scale (Kern - Voltadol)"
  dm
  # Variances for each formulation (at log scale)
  tapply(PCs[,1], diclofenac$Form, var)
  # Ratio of geometric means Kern/Voltadol at original scale
  gmr <- exp(dm)
  names(gmr) <- "Geometric means ratio at original scale (Kern / Voltadol)"
  gmr

  # Bioequivalence analysis for the first principal component:
  summaryAnalysis("PC1", data = cbind(diclofenac[,1:3], data.frame(pcs)))

  # ---------------------------------------------------------------------------------------------
  #                                    Discriminant Analysis
  # ---------------------------------------------------------------------------------------------
  require(MASS)
  rheology.lda <- lda(grouping = diclofenac[,"Form"], x = logRheology)
  plot(rheology.lda)
  # Linear discriminant value of each multivariate observation (in log scale):
  discrFunc <- scale(logRheology, center = colMeans(rheology.lda$means), scale = FALSE) %*%
    rheology.lda$scaling
  hist(discrFunc, breaks = 25)
  plot(density(discrFunc))
  var(discrFunc)

  # Again, a rescaling seems appropriate and necessary, but not clear how in advance.
  # A conservative (against the possibility of declaring BE), rescale accordin to the
  # maximum log rheology variance estimate:
  discrFunc <- (discrFunc / sd(discrFunc)) * sqrt(max(var.rheoVars))
  var(discrFunc)

  # Linear discriminant values at rheology variables original scale:
  ld <- exp(discrFunc)
  hist(ld, breaks = 25)
  plot(density(ld))

  mld <- tapply(discrFunc, diclofenac$Form, mean)
  # Difference of means at logarithmic scale:
  dm <- mld["Kern"] - mld["Voltadol"]
  names(dm) <- "Means difference at log scale (Kern - Voltadol)"
  dm
  # Variances for each formulation at logarithmic scale:
  tapply(discrFunc, diclofenac$Form, var)
  # Ratio of geometric means Kern/Voltadol at original scale
  gmr <- exp(dm)
  names(gmr) <- "Geometric means ratio at original scale (Kern / Voltadol)"
  gmr
  summaryAnalysis("LD1", data = cbind(diclofenac[,1:3], data.frame(ld)))

  # *********************************************************************************************
  #                                EXTENSIBILITY
  # *********************************************************************************************
  # Area in mm? occupied by the formulations after placing the corresponding weight in grams
  # (37g, 87g, 187g and 387g) for 5 minutes.
  # summaryAnalysis("W37", data = diclofenac)          # BE with 0.8/1.25 limits (not 0.9/1.11)
  #
  # summaryAnalysis("W87", data = diclofenac)
  #
  # summaryAnalysis("W187", data = diclofenac)
  #
  # summaryAnalysis("W387", data = diclofenac)         # BE with 0.8/1.25 limits (not 0.9/1.11)
  #
  # Area under de curve of "area vs. weight", AUC,
  summaryAnalysis("AUC", data = diclofenac)

}

