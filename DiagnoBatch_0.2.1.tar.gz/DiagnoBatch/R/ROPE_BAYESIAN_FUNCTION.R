#equivalencia bayesiana

#ver el articulo de:

#https://www.r-bloggers.com/rope-and-equivalence-testing-practically-equivalent/


#ejemplo

#set.seed(1)
#x<-rnorm(100) #Generate 100 random normally distributed observations
#y<-rnorm(100) #Generate 100 random normally distributed observations

ROPE_EQUIVALENCE_BAYESIAN <- function(x,y){

  #When we perform a study, we would like to conclude there is an effect,
  #when there is an effect. But it is just as important to be able to conclude
  #there is no effect, when there is no effect. I’ve recently published a paper
  #that makes Frequentist equivalence tests (using the two-one-sided tests, or
  #TOST, approach) as easy as possible (Lakens, 2017). Equivalence tests allow you to reject the presence of any effect you care about. In Bayesian estimation, one way to argue for the absence of a meaningful effect is the Region of Practical Equivalence (ROPE) procedure (Kruschke, 2014, chapter 12), which is “somewhat analogous to frequentist equivalence testing” (Kruschke & Liddell, 2017).


  #Make sure JAGS is installed or R will crash: https://sourceforge.net/projects/mcmc-jags/files/JAGS/4.x/
  require(BEST) #To calculate HDI
  require(TOSTER) #To calculate Equivalence Tests


  #ROPE test
  BESTout<-BESTmcmc(x,y)
  plot(BESTout)

  #TOST test
  TOSTtwo.raw(m1=mean(x),m2=mean(y),sd1=sd(x),sd2=sd(y),n1=length(x),n2=length(y),low_eqbound=-0.5,high_eqbound=0.5, alpha=0.025)


  #ROPE power analysis
  # 1. Generate idealised data set:
  proData <- makeData(mu1=0, sd1=1, mu2=0, sd2=1, nPerGrp=10000,
                      pcntOut=0, sdOutMult=1.0, rnd.seed=1)

  # 2. Generate credible parameter values from the idealised data:
  proMCMC <- BESTmcmc(proData$y1, proData$y2, numSavedSteps=2000)

  # 3. Compute the prospective power for planned sample sizes:
  # We'll  do just 5 simulations to show it works; should be several hundred.

  N1plan <- N2plan <- 100
  powerPro <- BESTpower(proMCMC, N1=N1plan, N2=N2plan,
                        ROPEm=c(-0.5,0.5), ROPEsd=c(-10,10), ROPEeff=c(-10,10),
                        maxHDIWm=15.0, maxHDIWsd=10.0, maxHDIWeff=10.0, nRep=2000)
  powerPro

  #TOST power analysis
  powerTOSTtwo.raw(alpha=0.025,statistical_power=0.875,low_eqbound=-0.5,high_eqbound=0.5,sdpooled=1)
}
