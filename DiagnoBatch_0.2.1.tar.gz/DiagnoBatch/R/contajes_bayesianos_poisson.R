

#' Bayesian counting (with applications to microbiology).
#' @param counts vector with countings
#' @return print with BCI bayesian credible interval of counts suposing a Poisson prior distribution
#' @export
#'
#' @examples
#' #####################
#' #FIRST EXAMPLE
#' #####################
#'
#' #Count microorganisms in Petri plaques
#' #Variability analysis between levels of the factor (ex: batch factor)
#' Bayesian.counting(counts=c(0,50,300,70,0,400,300,8000,0) )
#'


Bayesian.counting<- function(counts){
  #para hacer contajes microbiologicos


  #contajes bayesianos microbiologicos

  #  Return the model specification and starting values for a
  # lognormal Poisson, then run the model using run.jags:


  #install.packages("bayescount")
  library(bayescount)
  #model <- run.model(model="LP", data=data, call.jags=FALSE)
  library('runjags')
  #results <- extend.jags(model, burnin=5000, sample=10000)


  # use a zero-inflated lognormal Poisson model to analyse some count
  # data, and suppressing JAGS output:
  #
  ## Not run:
  results1 <- bayescount.single(data=counts,
                               model="ZILP", silent.jags=TRUE)
  ## End(Not run)

  res.principal<- paste("Bayesian Median Counting ZILP (BCI-95%) = ",
                        round(data.frame(results1)[6,1],2), " (",
                        round(data.frame(results1)[5,1],2)," - ",
                        round(data.frame(results1)[7,1],2), ")",sep = "")
  return(list(c(res.principal, "------------------------------------------------------", "All bayesian results = ", results1)))
  #ver en: https://rdrr.io/cran/bayescount/

}


