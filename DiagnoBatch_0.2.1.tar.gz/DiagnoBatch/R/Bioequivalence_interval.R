##########################################################
# Funcion para establecer bioequivalencia con el IC90% de Westlake
#########################################################
#funcion basada en parte en los apuntes de Didier Cortambert
#using a function to establish BE using the ration of geometric mean (Westlake)
Confidence.intervalBE <- function(mean.T, mean.R,   alfa=0.05,
                                  pool.variance,n1, n2, crossover=T, Bioequivalence.Criteria=20){

  #criterio de bioequivalencia, se refiere a:
  #https://www.certara.com/2011/01/24/where-did-the-80-125-bioequivalence-criteria-come-from/?
  #Bioequivalence.Criteria=20,30,40 #standart


  #function to calculate BE, based on pag61 Concordet

  #Build a 1-2a (90% for a consumer risk a = 5%) confidence interval for R T
  if(crossover==T){
    A<-0.5 #cross-over=0.5
  }
  if(crossover==F){
    A<-1 #parallel groups
  }

  t<-qt(1-alfa,n1+n2-2) #tstudent

  #lower BE limit
  (mean.T-mean.R) - t*sqrt(A*pool.variance*((1/n1)+(1/n2)))
  li<-(mean.T-mean.R) - t*sqrt(A*pool.variance*((1/n1)+(1/n2)))

  #upper BE limit
  (mean.T-mean.R) + t*sqrt(A*pool.variance*((1/n1)+(1/n2)))
  lu<-(mean.T-mean.R) + t*sqrt(A*pool.variance*((1/n1)+(1/n2)))

  #Clinical Range	± ln(ratio)	Acceptable Range
  #± 20%	± 0.223	80 – 125%
  #± 30%	± 0.357	70 – 143%
  #± 50%	± 0.693	50 – 200%
  #dependiendo de los criterios de bioequivalencia
  if(Bioequivalence.Criteria==20 ){
    print("BE confidence interval ([ 0.8 ;  1.25] = ln(ratio) [-0.223 ; +0.223])")
  }
  #dependiendo de los criterios de bioequivalencia
  if(Bioequivalence.Criteria==30 ){
    print("BE confidence interval ([ 0.7 ;  1.43] = ln(ratio) [-0.357 ; +0.357])")
  }
  #dependiendo de los criterios de bioequivalencia
  if(Bioequivalence.Criteria==40 ){
    print("BE confidence interval ([ 0.5 ;  2] = ln(ratio) [-0.693 ; +0.693])")
  }

  #sample results Bioequivalence interval Westlake
  print("sample BE Westlake interval: ln(ratio)")
  print(c(li,lu))
  print("sample BE Westlake interval: BE ratio ")
  print(exp(c(li,lu)))
  #declaration bioequivalence
  if(Bioequivalence.Criteria==20 ){
    print("BE confidence interval ([ 0.8 ;  1.25] = ln(ratio) [-0.223 ; +0.223])")
    if(li>=-0.223 & lu<=0.223){ print("It is possible to declare bioequivalence")  }
    #if(li<-0.223 | lu>0.223){ print("Is not possible to declare bioequivalence !!!!!")  }
  }
  #dependiendo de los criterios de bioequivalencia
  if(Bioequivalence.Criteria==30 ){
    print("BE confidence interval ([ 0.7 ;  1.43] = ln(ratio) [-0.357 ; +0.357])")
    if(li>=-0.357 & lu<=0.357){ print("It is possible to declare bioequivalence !!!!!")}
    #if(li<-0.357 | lu>0.357){ print("Is not possible to declare bioequivalence")  }
  }
  #dependiendo de los criterios de bioequivalencia
  if(Bioequivalence.Criteria==40 ){
    print("BE confidence interval ([ 0.5 ;  2] = ln(ratio) [-0.693 ; +0.693])")
    if(li>=-0.693 & lu<=0.693){ print("It is possible to declare bioequivalence !!!!!")  }
    #if(li<-0.693 | lu>0.693){ print("Is not possible to declare bioequivalence")  }
  }

}

#examples
#application examle of the function for the BE CI
#print("\n")
#print("20% bioequivalence ---------------------------")
#Confidence.intervalBE(mean.T=mean.T, mean.R=mean.R,alfa = 0.05,   pool.variance=pool.variance, n1=10, n2=10, crossover=F, Bioequivalence.Criteria=20)

#print("\n")
#print("30% bioequivalence ---------------------------")
#Confidence.intervalBE(mean.T=mean.T, mean.R=mean.R,alfa = 0.05,   pool.variance=pool.variance, n1=10, n2=10, crossover=F, Bioequivalence.Criteria=30)

#print("\n")
#print("40% bioequivalence ---------------------------")
#Confidence.intervalBE(mean.T=mean.T, mean.R=mean.R,alfa = 0.05,   pool.variance=pool.variance, n1=10, n2=10, crossover=F, Bioequivalence.Criteria=40)

#So, with an interval = [0.5551396-1.4393828] we Conclude to bioinequivalence [0.8 ; 1.25] if this interval is not totally included in the equivalence interval [D1 ; D2]


