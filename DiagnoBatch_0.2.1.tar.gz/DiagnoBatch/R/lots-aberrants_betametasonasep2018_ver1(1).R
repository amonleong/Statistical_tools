
#############################################################################
#  COEFFICIENTS OF VARIATION ANALYSIS BETWEEN LEVELS: APLICATION TO QUALITY CONTROL IN BIOEQUIVALENCE, BATCH EFFECT AND OTHERS
##############################################################################

# Toni Monleon. Biost3. 9-9-2018

#' COEFFICIENTS OF VARIATION ANALYSIS: Englemann-Hecker-Plot that includes Test of Feltz and Miller’ (1996) & Krishnamoorthy and Lee’s (2014) for the differences between variability coefficiets
#' @param X matrix with  data-set matrix with variables measured
#' @param Batches vector with  levels of factor where variability between levels is analyzed
#' @param alpha1 level alpha for tests of variability, by defect 0.05
#' @param PCA.transform do the analysis using PCA tranformed variables PCA1 and PCA2, by defect is T
#' @param center.PCA when use PCA tranformed variables PCA1 and PCA2, center the variables, by defect is T
#' @param scale.PCA when use PCA tranformed variables PCA1 and PCA2, scale the variables, by defect is T
#' @return plots and tests of Feltz and Miller’ (1996) & Krishnamoorthy and Lee’s (2014) for the differences between variability coefficiets
#' @export
#'
#' @examples
#' #####################
#' #FIRST EXAMPLE
#' #####################
#'
#' #Simulate an experiment with a batch factor (3 bathes) and 3 variables
#' Reference_batches_simulated  <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10)), var1 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var2 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var3 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)))

#' #Do a variability analysis of batches and CV differences
#' Englemann.Hecker.Plot.Algorithm(X=Reference_batches_simulated[,2:4],Batches=Reference_batches_simulated$Bat)

#' #Complement the analysis with function Check.variance.test()
#' Check.variance.test(X=Reference_batches_simulated[,2:4],Batches=Reference_batches_simulated$Bat,Resampling = T,alpha1 = 0.001, nremuestras = 10000 )
#'
#' ###################
#' #SECOND EXAMPLE
#' ###################
#' #sIMULATE A FACTOR WITH 5 bathes and 3 variables
#' Batches.referencia.simulados <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10),rep("B4",10),rep("B5",10)),
#'                                           var1 = c(rnorm(10,55,12), rnorm(10,55,4), rnorm(10,55,4),rnorm(10,55,4),rnorm(10,55,4)),
#'                                           var2 = c(rnorm(10,5500,890), rnorm(10,5500,400), rnorm(10,5500,400),rnorm(10,5500,400),rnorm(10,5500,400)),
#'                                           var3 = c(rnorm(10,12,7), rnorm(10,12,4), rnorm(10,12,4),rnorm(10,12,4),rnorm(10,12,4)))
#'
#'#' #Do a variability analysis of batches and CV differences
#' Englemann.Hecker.Plot.Algorithm(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat)
#'
#' #Analyze all variables
#' Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000 )
#' #Only 2 first PCA components
#' Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000,PCA.transform = T )


#' @references
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.


##############################################################################
# representar la variabilidad de los batches, de todas las variables
# Englemann-Hecker-Plot algorithm that includes Test of Feltz and Miller’ (1996) & Krishnamoorthy and Lee’s (2014)
# for the differences between variability coefficiets
##############################################################################
Englemann.Hecker.Plot.Algorithm <- function(X,Batches,alpha1=0.05, PCA.transform=T, center.PCA = T, scale.PCA=T){

  #SI SE REALIZA PCA de todas las variables, hay que estandarizar y centrar si las variables tienen unidades muy diferentes
  # ya que a varinza puede ser mayor debido a que las unidades sean mayores

  par(mfrow=c(3,4), mar=c(3,2,3,2), oma =c(7,0,3,0), cex.main = 0.8)

  #trasnformar todas las variables a PCA
  if (PCA.transform ==T){
    #transformar todas las variables que entran a PCA Y COGER SOLO LAS 2 PRIMERAS
    ir.pca <- prcomp(X,
                     center = center.PCA,
                     scale. = scale.PCA) #no se estandariza para mantener la variabilidad
    # print method
    print("RESULTS PCA ANALYSYS--------------------------------")
    print(ir.pca)
    # plot method
    plot(ir.pca, type = "l")
    # summary method
    print(summary(ir.pca))
    # Predict PCs
    #predict(ir.pca)[,1] #elementos componente1
    #predict(ir.pca)[,2] #elementos componente 2
    plot(predict(ir.pca)[,1], predict(ir.pca)[,2], pch=18, col=rainbow(nlevels(as.factor(Batches)), alpha=0.6)[as.numeric(as.factor(Batches))])
    title(main="PCA all variables", col.main="red",
          sub="Non standarized", col.sub="blue",
          xlab="PC1", ylab="PC2",
          col.lab="green", cex.lab=0.75)
    text(predict(ir.pca)[,1], predict(ir.pca)[,2],
         Batches, cex=0.6, pos=4, col=rainbow(nlevels(as.factor(Batches)), alpha=0.6)[as.numeric(as.factor(Batches))])
    abline(h=0, v=0)

    #dibujar un bibplot
    require(graphics)
    #si las variables son centradas:
    if (center.PCA == T){
      # center with 'apply()'
      center_apply <- function(x) {
        apply(x, 2, function(y) y - mean(y))
      }
      #do a biblop with scale and centered
      biplot(princomp(center_apply(X),cor = scale.PCA),xlab="PC1", ylab="PC2",main = "biplot")
    }
    #si las variables son centradas:
    if (center.PCA == F){
      #do a biblop with scale and centered
      biplot(princomp((X),cor = scale.PCA),xlab="PC1", ylab="PC2",main = "biplot")
    }


    #mejorar plot pca, poner etiquetas y un circulo segun lejania al centro
    #con colores de semaforo: outlyers
    X<- data.frame(predict(ir.pca)[,1], predict(ir.pca)[,2])

    #tratamiento de outlyers y cercania al centro------------------------
    #ver en: https://pubs.rsc.org/en/content/articlehtml/2014/ay/c3ay41907j
    #predict(ir.pca)[,1], predict(ir.pca)[,2]
    #deteccion de outlyers usando test Grubbs y otros
    #ver en
    #https://statistique-et-logiciel-r.com/comment-detecter-les-outliers-avec-r/
    #METODO DE LOS PERCENTILES
    pinf = 0.025 # fixe le percentile de limite inférieure
    psup = 0.975# fixe le percentile de limite inférieure
    binf.pc1 <- quantile(predict(ir.pca)[,1],pinf) # calcule la borne inf de l'intervalle
    bsup.pc1<- quantile(predict(ir.pca)[,1],psup) # calcule la borne sup de l'intervalle
    binf.pc2 <- quantile(predict(ir.pca)[,2],pinf) # calcule la borne inf de l'intervalle
    bsup.pc2<- quantile(predict(ir.pca)[,2],psup) # calcule la borne sup de l'intervalle
    #3.2 La méthode de Hampel
    #Une autre méthode, dite de Hampel, consiste à considérer comme outliers les valeurs en dehors de l’intervalle constitué par la médiane, plus ou moins 3 déviation absolue de médiane :
    #  I=[median–3∗mad;median+3∗mad]
    #Avec mad=Median Absolute Deviation
    #method Hampel 3 medianas
    k= 3
    binf.pc1.h<- median(predict(ir.pca)[,1]) - k * mad (predict(ir.pca)[,1]) # calcule la borne inf de l'intervalle
    bsup.pc1.h <- median(predict(ir.pca)[,1]) + k * mad (predict(ir.pca)[,1]) # calcule la borne sup de l'intervalle
    binf.pc2.h<- median(predict(ir.pca)[,2]) - k * mad (predict(ir.pca)[,2]) # calcule la borne inf de l'intervalle
    bsup.pc2.h <- median(predict(ir.pca)[,2]) + k * mad (predict(ir.pca)[,2]) # calcule la borne sup de l'intervalle

    mi1.pc1<-min(binf.pc1.h, binf.pc1, min(predict(ir.pca)[,1]))
    ma1.pc1<-max(bsup.pc1.h, bsup.pc1, max(predict(ir.pca)[,1]))
    mi1.pc2<-min(binf.pc2.h, binf.pc2, min(predict(ir.pca)[,2]))
    ma1.pc2<-max(bsup.pc2.h, bsup.pc2, max(predict(ir.pca)[,2]))

    #PLOT pca CON LOS LIMITES DE LOS OUTLYERS
    plot(predict(ir.pca)[,1], predict(ir.pca)[,2], pch=18, col=rainbow(nlevels(as.factor(Batches)), alpha=0.6)[as.numeric(as.factor(Batches))],
         xlim=c(mi1.pc1,ma1.pc1), ylim=c(mi1.pc2,ma1.pc2))
    title(main="PCA: OUTLYERs. PERCENTIL(g)/HAMPEL(y)", col.main="red",
          sub="Non standarized", col.sub="blue",
          xlab="PC1", ylab="PC2",
          col.lab="green", cex.lab=0.75)
    text(predict(ir.pca)[,1], predict(ir.pca)[,2],
         Batches, cex=0.6, pos=4, col=rainbow(nlevels(Batches), alpha=0.6)[as.numeric(Batches)])
    #x1<-mean(predict(ir.pca)[,1])
    #y1<-mean(predict(ir.pca)[,2])
    #draw.circle(x1,y1,radius=,nv=100,border=NULL,col=NA,lty=1,density=NULL,
    #            angle=45,lwd=1)
    #limites percentiles
    abline(v=binf.pc1,  col="green")
    abline(v=bsup.pc1,  col="green")
    abline(h=binf.pc2,  col="green")
    abline(h=bsup.pc2,  col="green")
    #limites
    abline(v=binf.pc1.h,  col="yellow")
    abline(v=bsup.pc1.h,  col="yellow")
    abline(h=binf.pc2.h,  col="yellow")
    abline(h=bsup.pc2.h,  col="yellow")


    library(outliers)
    print("")
    print("------------------------------------------------------")
    print("OUTLYERS DETECTION-----------------------------------")
    #test for outlyers
    print("Test of Grubbs for outlyers 1st dimension PCA")
    print(grubbs.test(predict(ir.pca)[,1]))
    #test for outlyers
    print("Test of Grubbs for outlyers 2nd dimension PCA")
    print(grubbs.test(predict(ir.pca)[,2]))
    print("")
  }


  #transform
  Y<-cbind(X,Batches)
  Y<-Y[order(Batches),]
  #View(Y)
  #class(Y)
  Y<-data.frame(Y)
  #X = variables que se tienen en cuenta en la variabilidad
  #Batches = nombre de los batches de referencia
  #alpha = nivel de significacion en el que se rechaza Ho (no son mass variables, test de Cochram)
  #nremuestras = numero de veces que se hace este test, muestreo con remplazamiento de muestras -> replace=TRUE
  #max.perc.var = 10 maximum percentage of variability admitted in the plot for all variables
  #PCA.do = Y hacer s?lo un PCA, dar sus resultados y hacer el analisis de variabilidad de los batches con las dos primeras componentes

  #parametros graficos
  library("plotrix")
  #quartz(width = 10)


  #check if variances are upper than mean in a serie of batches for a simgle variable
  #for (i in 1:(dim(Y)[2]-1)){ #para cada variable V1, v2, V3, etc
  #analisis para cada una de las variables
  #i<-1


  ################################################################
  # TIPO DE GRAFICO PARA INTEGRAR TODAS LAS VARIABLES POR BATCHES
  #################################################################

  sapply(1:(dim(Y)[2]-1), function(i) ehplot(as.matrix(Y[,i]), groups =  Y$Batches,
                                             offset = 0.2,
                                             col=rainbow(nlevels(Y$Batches), alpha=0.6)[as.numeric(Y$Batches)],
                                             pch = 19,
                                             main = names(Y[i]),
                                             xlab = "Batches",
                                             box = T), USE.NAMES = F)
  mtext(" Englemann-Hecker-Plot FOR EACH VARIABLE\n",
        outer = TRUE, cex = 1)




  #convertir a dataframe de cada variable columna
  #aa<-data.frame(Batches,X[,i])
  #colnames(aa)<-c("Batches","Var1")

  #cochran.test: OUTLYERS
  #res.co<-cochran.test(Var1 ~ Batches, aa, inlying=F) #VARIANZA SUPERIOR A LA NORMAL


  # }

  #solo si hay PCA analisis para multiples variables
  if (PCA.transform ==T){

    #ver si hay un efecto batch con ANOVA

    res.AOV <- aov(X[,1] ~ Batches, data =Y)
    print("")
    print("----------------------------------------------------------")
    print("Effect batch using ANOVA ONEWAY 1st component PCA------------------")
    print(summary(res.AOV))
    #graficos de diagnosticos varianza 1ª componente PCA
    plot(res.AOV)

    #2ª componente
    res.AOV1 <- aov(X[,2] ~ Batches, data =Y)
    print("")
    print("----------------------------------------------------------")
    print("Effect batch using ANOVA ONEWAY 2nd component PCA------------------")
    print(summary(res.AOV1))
    #graficos de diagnosticos varianza
    plot(res.AOV1)

    #test the variance
    #Compute Fligner-Killeen test in R
    #The Fligner-Killeen test is one of the many tests for homogeneity of variances which is most robust against departures from normality.
    print("\n")
    print("----------------------------------------------------------")
    print("PC1: Homogeneity of variances between batches using robust Fligner-Killeen test ------------------")
    resft1<- fligner.test(X[,1]~Batches, data =Y)
    print(resft1)
    print("\n")
    print("----------------------------------------------------------")
    print("PC2: Homogeneity of variances between batches using robust Fligner-Killeen test ------------------")
    resft2<- fligner.test(X[,2]~Batches, data =Y)
    print(resft2)

    #hacer test de comparacion de Coefficient of variation between batches
    library(cvequality)
    library(ggplot2)
    library(ggbeeswarm)

    # test de Feltz and Miller’s (1996) asymptotic test:
    library(cvequality)
    #PC1------------------------------------
    cv_test_Feltz <-
      with(Y, asymptotic_test(X[,1],
                              Batches))
    print("\n")
    print("----------------------------------------------------------")
    print("PC1: Test of Feltz and Miller s (1996) asymptotic test for Coefficient of variation")
    print(cv_test_Feltz)

    #We can repeat the test with Krishnamoorthy and Lee’s (2014) modified signed-likelihood ratio test:
    cv_test_MSLRT <- with(Y, mslr_test(nr = 1e4, X[,1], Batches))
    print("\n")
    print("----------------------------------------------------------")
    print("PC1: Test of Krishnamoorthy and Lee’s (2014) Coefficient of variation")
    print(cv_test_MSLRT)

    #PC2------------------------------------
    cv_test_Feltz2 <- with(Y, asymptotic_test(X[,2],Batches))
    print("\n")
    print("----------------------------------------------------------")
    print("PC2: Test of Feltz and Miller’s (1996) asymptotic test Coefficient of variation")
    print(cv_test_Feltz2)

    cv_test_MSLRT <- with(Y, mslr_test(nr = 1e4, X[,2], Batches))
    print("\n")
    print("----------------------------------------------------------")
    print("PC2: Test of Krishnamoorthy and Lee’s (2014) Coefficient of variation")
    print(cv_test_MSLRT)

    #We can repeat the test with Krishnamoorthy and Lee’s (2014) modified signed-likelihood ratio test:
    #cv_test_MSLRT <-
    #  with(Calcipotriol_sep2018,
    #       mslr_test(nr = 1e4,
    #                 SRperc,
    #                NumBatch))

    #cv_test_MSLRT
  }



  #solo si no hay PCA analisis y solo una unica variable
  if (PCA.transform == F & ncol(Y)==2){
    #class(X)
    #ver si hay un efecto batch con ANOVA

    res.AOV <- aov(Y$X ~ as.factor(Y$Batches))
    print("")
    print("----------------------------------------------------------")
    print("Effect batch using ANOVA ONEWAY------------------")
    print(summary(res.AOV))
    #graficos de diagnosticos ANOVA
    plot(res.AOV)

    #test the variance
    #Compute Fligner-Killeen test in R
    #The Fligner-Killeen test is one of the many tests for homogeneity of variances which is most robust against departures from normality.
    print("\n")
    print("----------------------------------------------------------")
    print("Homogeneity of variances between batches using robust Fligner-Killeen test ------------------")
    resft1<- fligner.test(Y$X~as.factor(Y$Batches))
    print(resft1)
    print("\n")
    print("----------------------------------------------------------")


    #hacer test de comparacion de Coefficient of variation between batches
    library(cvequality)
    library(ggplot2)
    library(ggbeeswarm)

    # test de Feltz and Miller’s (1996) asymptotic test:
    library(cvequality)
    #PC1------------------------------------
    cv_test_Feltz <-
      with(Y, asymptotic_test(Y$X,
                              as.factor(Y$Batches)))
    print("\n")
    print("----------------------------------------------------------")
    print("Test of Feltz and Miller s (1996) asymptotic test for Coefficient of variation")
    print(cv_test_Feltz)

    #We can repeat the test with Krishnamoorthy and Lee’s (2014) modified signed-likelihood ratio test:
    cv_test_MSLRT <- with(Y, mslr_test(nr = 1e4, Y$X, Y$Batches))
    print("\n")
    print("----------------------------------------------------------")
    print("Test of Krishnamoorthy and Lee’s (2014) Coefficient of variation")
    print(cv_test_MSLRT)

    print("----------------------------------------------------------")
    print("Test de cochran.test: inlying variance=T")
    #Test de cochran.test
    library(outliers)
    res.co1<-cochran.test(X~ Batches, Y, inlying=T) #VARIANZA SUPERIOR A LA NORMAL
    print(res.co1)

    print("----------------------------------------------------------")
    print("Test de cochran.test: inlying variance=F")
    #Test de cochran.test
    library(outliers)
    res.co2<-cochran.test(X~ Batches, Y, inlying=F) #VARIANZA SUPERIOR A LA NORMAL
    print(res.co2)


  }



}
