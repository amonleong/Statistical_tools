#ptions(show.signif.stars=FALSE, contrasts=c("contr.sum", "contr.poly"))
#library(car)
#source("newAnova2nest.R")
#source("ciWithBatches.R")

#from Jordi Ocanya - 2018-2018


summaryAnalysis <- function(response, form = "Form", batch = "Batch", test = "Kern",
                            data, random = batch, level = 0.90,
                            lowBELim = 0.9, uppBELim = 1 / lowBELim, plot.display=T)
{
  cat("BASIC BIOEQUIVALENCE ANALYSIS OF", response, "\n")
  cat("================================================================\n")
  logData <- data[,c(form,batch,response)]
  logData[,response] <- log(data[,response])
  logRespName <- paste("log",response, sep = "")
  colnames(logData)[3] <- logRespName
  logCi <- ciWithBatches(logRespName, form, batch, test, data = logData, random = random, level = level)
  cat("Confidence interval at log scale and its attributes:\n")
  print(logCi)
  cat("................................................................\n")
  ci <- exp(logCi[1:2])
  cat("Confidence interval at original scale as a ratio:\n")
  print(ci)
  cat("Bioequivalence limits at original scale as a ratio: [",
      lowBELim, ",", uppBELim, "]\n")
  if ((lowBELim <= ci[1]) && (ci[2] <= uppBELim)){
    cat("Confidence interval inside limits: Bioequivalence can be declared\n")
    declaracio <- 1
  } else {
    cat("Confidence interval outside limits: It is not possible to declare bioequivalence\n")
    declaracio <- 0
  }
  aovTable <- attr(logCi, "aov.table")
  msE <- aovTable[3,3]
  means <- exp(attr(logCi, "means"))
  cat("Geometric means at original scale of", response, ":\n")
  print(means)
  formEff <- exp(attr(logCi, "formulation.effect"))
  formLevels <- levels(data[,form])
  cat("\nFormulation effect estimate as the ratio of geometric means (",
      test, "/", formLevels[which(formLevels != test)], "): ",
      formEff, "\n")
  varBatch <- max((aovTable[2,3] - msE) / attr(logCi, "n"), 0)
  cat("\nBatch variance estimate (log scale): ", varBatch,
      "    batch standard deviation:", sqrt(varBatch), "\n")
  cat("Residual variance estimate (log scale): ", msE,
      "    residual standard deviation:", sqrt(msE),  "\n")
  cat("Variance of", response, " (log scale):", varBatch + msE,
      "    standard deviation of", response, ":", sqrt(varBatch + msE),  "\n")
  # print(confint(result.aov, "Form", level = level))
  formul <- attr(logCi, "formula")
  result.aov <- aov(formul, data = logData)
  cat("Model diagnostics (at log scale):\n")
  if(plot.display == T){ #sols si es demana
    plot(result.aov)
  }
  print(leveneTest(formul, data = logData))
  print(shapiro.test(residuals(result.aov)))
  return(list(ci, declaracio)) #retorna els intervals de confiança de BE
}


ciWithBatches <- function(response, form = "Form", batch = "Batch", test = "Kern",
                          data, random = batch, level = 0.90)
{
  formul <- as.formula(paste(response, "~", form, "/", batch))
  aovTable <- anova2nest(aov(formul, data = data), random = random)
  means <- tapply(data[,response], data[,form], mean)
  N <- nrow(data)
  iref <- which(levels(data[,form]) != test)
  formEff <- means[test] - means[iref]
  names(formEff) <- paste(test, "-", levels(data[,form])[iref])
  ssizes <- replications(formul, data = data)[[2]]
  n <- ncol(ssizes) / sum(1 / colSums(ssizes))
  nbatches <- tapply(data[,batch], data[,form],
                     function(batchLevels, allLevels) {
                       sum(allLevels %in% batchLevels)
                     },
                     levels(data[,batch]))
  ddf <- sum(nbatches) - 2
  talpha <- qt(0.5 * (1 - level), df = ddf)
  conf.int <- formEff - c(-talpha, talpha) *
    sqrt(aovTable[2,3] * sum(1 / nbatches) / n)
  attr(conf.int, "conf.level") <- level
  attr(conf.int, "formula") <- formul
  attr(conf.int, "n") <- n
  attr(conf.int, "means") <- means
  attr(conf.int, "formulation.effect") <- formEff
  attr(conf.int, "aov.table") <- aovTable
  return(conf.int)
}


doSampling <- function(dat,varBE,numSamples,sizeSamples, replacement=T, ci=0.9){
  library(dplyr)
  # calculate and plot a sampling distribution of the mean
  # parameters given are:
  # dat = data to sample from (numeric vector),
  # numSamples = number of times you want to sample (number)
  # sizeSamples = size of the sample (number)
  # returns a numeric vector with the values of the sample means
  out <- numeric(numSamples)
  for (i in seq(1,numSamples)){
    #i<-1
    # simple random sampling
    get_sample <- sample_n(dat, size = sizeSamples,replace = replacement)
    # calculate mean and store it in the numeric vector
    resBE<- summaryAnalysis(varBE, data = get_sample, lowBELim = ci, plot.display = F)
    out[i] <- resBE[2] #si es pot declarar (1) o no (0) BE
  }

  print("#########################################################################")
  #total declared BE
  print("Total declared Bioequivalent:")
  print(sum(as.numeric(out)))
  #% declared BE
  print("% declared Bioequivalent:")
  print(round(100*sum(as.numeric(out))/numSamples, 2))

  return(out)
}

anova2nest <- function (aovObj, random = NULL)
{
  nrandom <- length(random)
  aovTab <- anova(aovObj)
  if (nrandom == 0)
    return(aovTab)
  # yName <- as.character(aovObj$call$formula[[2]])
  modelNames <- names(aovObj$model)
  yName <- modelNames[1]
  if (!all(match(random, modelNames[-match(yName, modelNames)],
                 nomatch = 0)))
    stop("Algun dels factors aleatoris indicats no es un factor o no forma part del model")
  nestEff <- grep(":", rownames(aovTab))
  if (length(nestEff) != 1)
    stop("'anova2nest' espera rebre un model jerarquic de 2 factors")
  msNest <- aovTab[nestEff, 3]
  dfNest <- aovTab[nestEff, 1]
  correctF <- aovTab[1, "Mean Sq"]/msNest
  aovTab[1, "F value"] <- correctF
  aovTab[1, "Pr(>F)"] <- pf(correctF, aovTab[1, 1], dfNest,
                            lower.tail = FALSE)
  return(aovTab)
}
