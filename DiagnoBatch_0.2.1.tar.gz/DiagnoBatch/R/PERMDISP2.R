
###################################################################################################################################
#Marti Anderson's PERMDISP2 procedure for the analysis of multivariate homogeneity of group dispersions (variances)
######################################################################################################################################

# este metodo se basa en distancias estadisticas y es multivariante.

#ver en: http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/betadisper.html
#implementar este metodo que tambien es interesante

#Multivariate homogeneity of groups dispersions (variances)
#Description
#Implements Marti Anderson's PERMDISP2 procedure for the analysis of multivariate homogeneity of group dispersions (variances).


#' Implements Marti Anderson's PERMDISP2 procedure for the analysis of multivariate homogeneity of group dispersions (variances).
#' @param X matrix with  data-set matrix with variables measured
#' @param Batches vector with  levels of factor where variability between levels is analyzed
#' @param nresamples number of resamples for permutest, n=1000
#' @param dist distance used between variables, can be all of "manhattan", "euclidean", "canberra", "bray", "kulczynski", "jaccard", "gower", "altGower", "morisita", "horn", "mountford", "raup" , "binomial", "chao", "cao" or "mahalanobis".
#' @return plots variability analysis, plots for all variables and final multivariate analysis for all variables
#' @export
#'
#' @examples
#' #####################
#' #FIRST EXAMPLE
#' #####################
#'
#' #Simulate an experiment with a batch factor (3 bathes: different variances) and 3 variables
#' Batches.simulated <- data.frame(Bat = c(rep("B1",5),rep("B2",5),rep("B3",5)),
#'                                           var1 = c(rnorm(5,55,15), rnorm(5,55,4), rnorm(5,55,4)),
#'                                           var2 = c(rnorm(5,60,15), rnorm(5,60,4), rnorm(5,60,4)),
#'                                           var3 = c(rnorm(5,80,15), rnorm(5,80,4), rnorm(5,80,4)))
#'
#' #Variability analysis between levels of the factor (ex: batch factor)
#' Marti.Anderson.PERM(X=Batches.simulated[,2:4],Batches=Batches.simulated$Bat, nresamples = 1000, dist="euclidean" )
#'

Marti.Anderson.PERM <- function(X,Batches,  nresamples = 1000, dist="euclidean"){


  #based on http://cc.oulu.fi/~jarioksa/softhelp/vegan/html/betadisper.html
  library(vegan)
  #data(varespec)

  ## Bray-Curtis distances between samples
  dis <- vegdist(X,method = dist,na.rm = T)

  ## define groups (factor and levels)
  groups <- factor(Batches) #factor(c(rep(1,16), rep(2,8)), labels = c("grazed","ungrazed"))

  ## Calculate multivariate dispersions
  mod <- betadisper(dis, groups)
  mod

  print("Marti Anderson's PERMDISP2 procedure for the analysis of multivariate homogeneity of group dispersions (variances)")
  print(mod)

  ## Perform test
  anova(mod)
  print("ANOVA Perform test")
  print(mod)

  ## Permutation test for F
  pert<-permutest(mod, pairwise = TRUE,permutations = nresamples)
  print("Permutation test for F")
  print(pert)

  ## Tukey's Honest Significant Differences
  (mod.HSD <- TukeyHSD(mod))
  print("Tukey's Honest Significant Differences between groups")
  print(mod.HSD)
  plot(mod.HSD)

  ## Plot the groups and distances to centroids on the
  ## first two PCoA axes
  plot(mod,main="Marti Anderson's PERMDISP2 procedure")

  ## Draw a boxplot of the distances to centroid for each group
  boxplot(mod)

}




########################old ################################################################
#TukeyHSD.betadisper creates a set of confidence intervals on the differences between the mean distance-to-centroid of the levels of the grouping factor with the specified family-wise probability of coverage. The intervals are based on the Studentized range statistic, Tukey's 'Honest Significant Difference' method.

#library(vegan)
#data(varespec)

## Bray-Curtis distances between samples
#dis <- vegdist(varespec)

## First 16 sites grazed, remaining 8 sites ungrazed
#groups <- factor(c(rep(1,16), rep(2,8)), labels = c("grazed","ungrazed"))

## Calculate multivariate dispersions
#mod <- betadisper(dis, groups)
#mod

## Perform test
#anova(mod)

## Permutation test for F
#permutest(mod, pairwise = TRUE,permutations = 1000)

## Tukey's Honest Significant Differences
#(mod.HSD <- TukeyHSD(mod))
#plot(mod.HSD)

## Plot the groups and distances to centroids on the
## first two PCoA axes
#plot(mod)

## Draw a boxplot of the distances to centroid for each group
#boxplot(mod)

## simulate missing values in 'd' and 'group'
#groups[c(2,20)] <- NA
#dis[c(2, 20)] <- NA
#mod2 <- betadisper(dis, groups) ## warnings
#mod2
#permutest(mod, control = permControl(nperm = 100))
#anova(mod2)
#plot(mod2)
#boxplot(mod2)
#plot(TukeyHSD(mod2))
