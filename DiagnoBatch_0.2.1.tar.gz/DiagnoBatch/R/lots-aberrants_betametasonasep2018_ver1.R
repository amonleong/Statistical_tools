

###############################################################################################
# ANALISIS OUTLYERS DE LOTES DE REFERENCIA
###############################################################################################

#Test de Cochran para todas las variables de manera individual, donde se obtinen algunas variables con batches que presentan outlyers
#see: https://cran.r-project.org/web/packages/outliers/outliers.pdf
# more at: https://www.researchgate.net/publication/320227689_Within-Laboratory_Variance_Outlier_Detection_An_Alternative_to_Cochran's_Test

####################(31-1-2019) nueva ya que hace mejor el remuestreo #######################################################################################
#funcion para el analisis de la variabilidad de los batches: usando test de Cochran para todas las variables y un test chi cuadrado para indicar si la distribucion de los que tienen m?s variabilidad es homogeneo o no------------v2------------------------------
###########################################################################################################
#sobre un conjunto de variables realiza el test de Cochram (ver referencia) n veces (remuestreo) y anota
#las veces que es significativo (p<alfa) y el batch que tiene maxima varianza (el significativo)
#puede mejorar la senbilidad del test si en vez de ver cual es el de maxima varianza utilizo un percentil de todas las varianzas de los
#batches y elijo aquellas que son superiores al percentil (ej: percentil 95) y los anoto en la lista




#############################################################################3
# QUALITY CONTROL IN BIOEQUIVALENCE: ANALYSIS OF VARIABILITY BETWEEN LEVELS
##############################################################################

# Toni Monleon. Biost3. 9-9-2018

#' Multivariate test of Cochran for the analysis of variability between levels
#' @param X matrix with  data-set matrix with variables measured
#' @param Batches vector with  levels of factor where variability between levels is analyzed
#' @param alpha1 level alpha for tests of variability, by defect 0.05
#' @param Resampling use resampling to test multiple variables, by defect T
#' @param size1 matrix size, by defect dim(X)[1]
#' @param max.perc.var max percentage of the variability, by defect = 50
#' @param PCA.transform do the analysis using PCA tranformed variables PCA1 and PCA2, by defect is F
#' @param center.PCA when use PCA tranformed variables PCA1 and PCA2, center the variables, by defect is T
#' @param scale.PCA when use PCA tranformed variables PCA1 and PCA2, scale the variables, by defect is T
#' @return plots variability analysis, plots for all variables and final multivariate analysis for all variables
#' @export
#'
#' @examples
#' #####################
#' #FIRST EXAMPLE
#' #####################
#'
#' #Simulate an experiment with a batch factor (3 bathes) and 3 variables
#' Reference_batches_simulated  <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10)), var1 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var2 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var3 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)))
#'
#' #Variability analysis between levels of the factor (ex: batch factor)
#' Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.001, nremuestras = 10000 )
#'
#' #Do a plot of variability analysis of batches and CV differences
#' Englemann.Hecker.Plot.Algorithm(X=Reference_batches_simulated[,2:4],Batches=Reference_batches_simulated$Bat)

#'
#' ###################
#' #SECOND EXAMPLE
#' ###################
#' #sIMULATE A FACTOR WITH 5 bathes and 3 variables
#' Batches.referencia.simulados <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10),rep("B4",10),rep("B5",10)),
#'                                           var1 = c(rnorm(10,55,12), rnorm(10,55,4), rnorm(10,55,4),rnorm(10,55,4),rnorm(10,55,4)),
#'                                           var2 = c(rnorm(10,5500,890), rnorm(10,5500,400), rnorm(10,5500,400),rnorm(10,5500,400),rnorm(10,5500,400)),
#'                                           var3 = c(rnorm(10,12,7), rnorm(10,12,4), rnorm(10,12,4),rnorm(10,12,4),rnorm(10,12,4)))
#'
#'#' #Analyze all variables
#' Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000 )
#' Only 2 first PCA components
#' Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000,PCA.transform = T )
#'#' #Do a variability analysis of batches and CV differences
#' Englemann.Hecker.Plot.Algorithm(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat)
#'


#' @references
#' Monleon-Getino T. 2018. Quantitative metagenomics. Lulu Press inc.



Check.variance.test.cochram <- function(X,Batches,  alpha1=0.05, Resampling=T, nremuestras = 100, size1 = dim(X)[1], max.perc.var = 50, PCA.transform=F, scale.PCA=T, center.PCA=T){

  #nremuestras = 3000
  #PCA.transform=T
  #par(mfrow=c(3,4), mar=c(3,2,3,2), oma =c(7,0,3,0), cex.main = 0.8)

  #trasnformar todas las variables a PCA
  if (PCA.transform ==T){
    #transformar todas las variables que entran a PCA Y COGER SOLO LAS 2 PRIMERAS
    ir.pca <- prcomp(X,
                     center = center.PCA,
                     scale. = scale.PCA) #no se estandariza para mantener la variabilidad
    # print method
    print("RESULTS PCA ANALYSYS--------------------------------")
    print(ir.pca)
    # plot method
    #plot(ir.pca, type = "l")

    plot(predict(ir.pca)[,1], predict(ir.pca)[,2], pch=18, col=rainbow(nlevels(as.factor(Batches)), alpha=0.6)[as.numeric(as.factor(Batches))], xlab="", ylab="")
    title(main="PCA all variables", col.main="red", col.sub="blue",
          xlab="PC1", ylab="PC2",
          col.lab="green", cex.lab=1)
    text(predict(ir.pca)[,1], predict(ir.pca)[,2],
         Batches, cex=0.6, pos=4, col=rainbow(nlevels(as.factor(Batches)), alpha=0.6)[as.numeric(as.factor(Batches))])
    abline(h=0, v=0)

    # summary method
    print(summary(ir.pca))
    # Predict PCs
    #predict(ir.pca)[,1] #elementos componente1
    #predict(ir.pca)[,2] #elementos componente 2
    #plot(predict(ir.pca)[,1], predict(ir.pca)[,2], xlab="PC!", ylab="PC2")
    #mejorar plot pca, poner etiquetas y un circulo segun lejaniaalcentro
    #con colores de semaforo: outlyers

    #dibujar un bibplot
    require(graphics)
    #si las variables son centradas:
    if (center.PCA == T){
      # center with 'apply()'
      center_apply <- function(x) {
        apply(x, 2, function(y) y - mean(y))
      }
      #do a biblop with scale and centered
      biplot(princomp(center_apply(X),cor = scale.PCA),xlab="PC1", ylab="PC2",main = "biplot")
    }
    #si las variables son centradas:
    if (center.PCA == F){
      #do a biblop with scale and centered
      biplot(princomp((X),cor = scale.PCA),xlab="PC1", ylab="PC2",main = "biplot")
    }

    X<- data.frame(predict(ir.pca)[,1], predict(ir.pca)[,2])
  }

  #outlyers detection using variance
  library(outliers)

  #X = variables que se tienen en cuenta en la variabilidad
  #Batches = nombre de los batches de referencia
  #alpha = nivel de significacion en el que se rechaza Ho (no son mass variables, test de Cochram)
  #nremuestras = numero de veces que se hace este test, muestreo con remplazamiento de muestras -> replace=TRUE
  #max.perc.var = 10 maximum percentage of variability admitted in the plot for all variables
  #PCA.do = Y hacer s?lo un PCA, dar sus resultados y hacer el analisis de variabilidad de los batches con las dos primeras componentes

  #cochran.test: OUTLYERS
  #res.co<-cochran.test(Var1 ~ Batches, aa, inlying=F) #VARIANZA SUPERIOR A LA NORMAL
  if (Resampling==T){
    #numero de batches
    #num.batches<-nlevels(aa$Batches)
    #nom.batches<-levels(aa$Batches)
    #guardar estadisticos
    my.array.statistics <- array(NA, dim=c(nremuestras,(1+2*dim(X)[2]))) #1ª columna nº remuestra, 2ª var1, 3ª batch.max.varianza...
    X1 <- cbind(X,Batches) #juntar batches y variables para el muestreo
    #remuestreear y reoger estadisticos de la variacion
    for (j in 1:nremuestras){
      #j<-1

      #remuestreo con reemplazo del mismo tamaño que la muestra y con correlacion
      aa1<-X1[sample(nrow(X1),size=size1,replace=T),]
      k<-0
      #en la primera columan de los estadisticos el numero de remuestreo
      my.array.statistics[j, 1]<-j #pvalor

      #para vcada variable
      for (i in 1: dim(X)[2]){
        #i<-1
        #test de Cochran
        #aa2<-data.frame(cbind(aa1[,i],Batches))
        aa2<- aa1[,c(i,dim(X)[2]+1)] #seleccionar la variable y codigo de los batches
        #cambio el nombre de la variable a testar, siempre se llamara V1
        names(aa2)[1]<-paste("V1")
        res.co<-cochran.test(V1 ~ Batches, aa2, inlying=F) #VARIANZA SUPERIOR A LA NORMAL

        #recoger estadisticos

        my.array.statistics[j, i+1+k]<-res.co$p.value #pvalor
        my.array.statistics[j, i+2+k]<-(which.max(res.co$estimate)) #batches
        k<-k+1

      }
    }

    #matriz de estadisticos
    my.array.statistics
    #table(my.array.statistics[,c(3,5,7,9,11,13,15,17,19)])
    #analizar los estadisticos recogidos (p valor y batch con maxima varianza)
    #imprimir resultados para cada variable y para el total de variables
    bbb<- NA #acumulador para todos los batches y variables
    #hacer esto para cada variable
    for (i in 1:(dim(X)[2]) ){
      #i es el numero de variable
      #i<-1
      #cada 2 espacios es una variable (2,4,6,8); num.vars = dim(X)[2]
      var.analizar.pvalor <- my.array.statistics[,(i*2):(2*i +1)]
      res.pvalor <- subset(var.analizar.pvalor, var.analizar.pvalor[,1] <alpha1)
      #solo si hay valores de pvalor < 0
      if (sum(res.pvalor)>0){
        batches.variabilidad.encimadelamedia<-(table(res.pvalor[,2]))

        #todas las variables y batches:
        bbb <- rbind(bbb, res.pvalor[,2])

        #dar un grafico de variabilidad total
        meds1 <- 100*(batches.variabilidad.encimadelamedia/nremuestras)
        #bmax <- max(100*table(batches.variabilidad.encimadelamedia)/(nremuestras*dim(X)[2]))
        #AQUI HAY UN PROBLEMA CON LAS ETIQUETAS
        #if(dim(meds1) != nlevels(aa$Batches)){
        #levels(aa$Batches)[c(1,2,4,5)]

        labs.batches<-levels(as.factor(Batches))[unique(sort(res.pvalor[,2]))]
        bp2 <- barplot(meds1, beside=TRUE,
                       axes=T, xlab="Batches with hight variability", col=rainbow(5)[c(4,1:3,5)],
                       ylab="Frequency (%)", ylim=c(0,100), names.arg=labs.batches)
        title(main=paste("Cochram test for: ", names(X[i]),i,sep=""), col.main="red", cex.lab=0.75)
        abline(h = max.perc.var,col="red")
      }


    }

    #barplot -------------------------------------------------------
    #CONTAJE DEL TOTAL - MULTIVARIANTE
    bbb1<- table(bbb)
    meds1 <- 100*bbb1/(dim(X)[2]*nremuestras)
    #bmax <- max(100*table(batches.variabilidad.encimadelamedia)/(nremuestras*dim(X)[2]))
    #AQUI HAY UN PROBLEMA CON LAS ETIQUETAS
    #if(dim(meds1) != nlevels(aa$Batches)){
    #levels(aa$Batches)[c(1,2,4,5)]
    labs.batches<-levels(as.factor(Batches))[as.numeric(names(bbb1))]
    bp2 <- barplot(meds1, beside=TRUE,
                   axes=T, xlab="Batches with hight variability all variables", col=rainbow(5)[c(4,1:3,5)],
                   ylab="Frequency (%)", ylim=c(0,100), names.arg=labs.batches)
    title(main=paste("Cochram test for: all variables",i,sep=""), col.main="red", cex.lab=0.75)
    abline(h = max.perc.var,col="red",lwd=2,lty="dotted") #maximo permitido de variailidad por encima de lo normal

    abline(h = 20,col="green") #bajo de variailidad por encima de lo normal
    abline(h = 40,col="yellow") #medio de variailidad por encima de lo normal
    abline(h = 80,col="red") #maximo  de variailidad por encima de lo normal


    #test sobre la uniformidad de los batches mas variables----------------
    #uniform test par saber si hay variabilidad en los batches o no
    #ks.unif<- ks.test(meds1, punif)
    #print("")
    #print("------------------------------------------------------")
    #print("KS test to detect outlyed variable batches: Uniform distribution")
    #print(ks.unif)
    #tulip <- c(1,  0.30)
    #num.batches<-nlevels(aa$Batches)
    res <- chisq.test(c(meds1), p = rep(1/length(meds1), length(meds1)))
    print("")
    print("---------------------------------------------------")
    print("Chi square test to detect outlyed variable batches: Uniform distribution Ho:p=1/n.batches")
    print(res)
  }

}


###########################################################################################################
#funcion para el analisis de la variabilidad de los batches: usando test de Cochran para todas las variables y un test chi cuadrado para indicar si la distribucion de los que tienen m?s variabilidad es homogeneo o no------------v2------------------------------
###########################################################################################################
#sobre un conjunto de variables realiza el test de Cochram (ver referencia) n veces (remuestreo) y anota
#las veces que es significativo (p<alfa) y el batch que tiene maxima varianza (el significativo)
#puede mejorar la senbilidad del test si en vez de ver cual es el de maxima varianza utilizo un percentil de todas las varianzas de los
#batches y elijo aquellas que son superiores al percentil (ej: percentil 95) y los anoto en la lista
Check.variance.test <- function(X,Batches, Coch.perc = F, alpha1=0.05, Resampling=T, nremuestras = 100, size1 = dim(X)[1], max.perc.var = 10, PCA.transform=F){

  #par(mfrow=c(3,4), mar=c(3,2,3,2), oma =c(7,0,3,0), cex.main = 0.8)

  #trasnformar todas las variables a PCA
  if (PCA.transform ==T){
    #transformar todas las variables que entran a PCA Y COGER SOLO LAS 2 PRIMERAS
    ir.pca <- prcomp(X,
                     center = F,
                     scale. = F) #no se estandariza para mantener la variabilidad
    # print method
    print("RESULTS PCA ANALYSYS--------------------------------")
    print(ir.pca)
    # plot method
    plot(ir.pca, type = "l")
    # summary method
    print(summary(ir.pca))
    # Predict PCs
    #predict(ir.pca)[,1] #elementos componente1
    #predict(ir.pca)[,2] #elementos componente 2
    plot(predict(ir.pca)[,1], predict(ir.pca)[,2], xlab="PC!", ylab="PC2")
    #mejorar plot pca, poner etiquetas y un circulo segun lejaniaalcentro
    #con colores de semaforo: outlyers
    X<- data.frame(predict(ir.pca)[,1], predict(ir.pca)[,2])
  }


  #outlyers detection using variance
  library(outliers)

  #X = variables que se tienen en cuenta en la variabilidad
  #Batches = nombre de los batches de referencia
  #alpha = nivel de significacion en el que se rechaza Ho (no son mass variables, test de Cochram)
  #nremuestras = numero de veces que se hace este test, muestreo con remplazamiento de muestras -> replace=TRUE
  #max.perc.var = 10 maximum percentage of variability admitted in the plot for all variables
  #PCA.do = Y hacer s?lo un PCA, dar sus resultados y hacer el analisis de variabilidad de los batches con las dos primeras componentes

  #inicializar
  batches.variabilidad.encimadelamedia <- NA

  #check if variances are upper than mean in a serie of batches for a simgle variable
  for (i in 1:dim(X)[2]){ #para cada variable V1, v2, V3, etc
    #analisis para cada una de las variables
    #i<-1
    par(mfrow=c(2,1))
    #BOXPLOT
    boxplot(as.matrix(X[,i]) ~Batches , col=terrain.colors(4))
    title(main = paste("Variable: " , names(X[,i]), sep=""))


    #convertir a dataframe de cada variable columna
    aa<-data.frame(Batches,X[,i])
    colnames(aa)<-c("Batches","Var1")

    #cochran.test: OUTLYERS
    res.co<-cochran.test(Var1 ~ Batches, aa, inlying=F) #VARIANZA SUPERIOR A LA NORMAL
    if (Resampling==T){
      #numero de batches
      num.batches<-nlevels(aa$Batches)
      nom.batches<-levels(aa$Batches)
      #guardar estadisticos
      my.array.statistics <- array(NA, dim=c(nremuestras,(1+num.batches)))



      #remuestreear y reoger estadisticos de la variacion
      for (j in 1:nremuestras){
        #j<-1
        #remuestreo con reemplazo del mismo tamaño que la muestra
        aa1<-aa[sample(nrow(aa),size=size1,replace=T),]

        #test de Cochran
        res.co<-cochran.test(Var1 ~ Batches, aa1, inlying=F) #VARIANZA SUPERIOR A LA NORMAL

        #recoger estadisticos
        my.array.statistics[j, 1]<-res.co$p.value #pvalor
        my.array.statistics[j, 2:(num.batches+1)]<-res.co$estimate #batches


      }
      #estadisticos recogidos, solo considerar si pvalor < alpha
      my.array.statistics
      #my.array.statistics <- array(NA, dim=c(nremuestras,(1+num.batches)))
      #cdf para ver % cuantos pvalores <0.05
      P = ecdf(my.array.statistics[,1])    # P is a function giving the empirical CDF of X
      cdf0.05<- P(alpha1)         # This returns the empirical CDF at zero (should be close to 0.5)
      #quantile.pvalor<-quantile(my.array.statistics[,1],probs = .95)

      #en este sitio se seleccionan los batches que tienen un p.valor significativo test cochram y que dan un valor superior a 95% varianza media
      elem<-NA
      for(j in 1:nremuestras){
        #j<-5
        #operaciones sobre los estadisticos
        vector<-my.array.statistics[j, 2:(num.batches+1)]
        p.valor.rem <- my.array.statistics[j, 1]
        elem<-c(elem, which(vector>quantile(vector,probs = (1-alpha1),na.rm = T) & p.valor.rem<alpha1))
      }

      #batches que se han muestreado superiores al 95% de su varianza media
      elem.sin.na<-as.vector(na.omit(elem))

    }


    #total de la muestra original
    #plot quality plot:-----------------------
    plot(as.vector(res.co$estimate), col="blue", xlab="batch", ylab="variance")
    abline(h=mean(res.co$estimate,na.rm = T),col="green") #varianza media para todos los batches
    abline(h=quantile(res.co$estimate,probs = (1-alpha1),na.rm = T),col="red") #quantile 95% media para todos los batches
    title(main = paste("Variable: " , names(X[,i]), sep=""))
    text1<-paste( "Cochran Test=", res.co$alternative , " ",  sep = "")
    mtext(text1, side = 3)
    text1<-paste( "pvalue=", round(res.co$p.value,2) , " ",  sep = "")
    mtext(text1, side = 4)

    #cuando hay cross validacion
    if (Resampling==T){

      meds <- table(elem.sin.na)
      meds <- table(elem.sin.na)
      bp <- barplot(meds, beside=TRUE, axes=FALSE, xlab="Batches with hight variability", col=c("azure3", "azure"),
                    ylab="Frequency (%)", ylim=c(0,max(table(elem.sin.na))))
      #axis(2, at=seq(0,max(table(elem.sin.na))))
      #legend("topright", legend=c("LOW", "HIGH"), bty="n", fill=c("azure3", "azure"))
      #text(bp, 0, round(medtimerx, 1), cex=1, pos=3)
      text1<-paste( "% pvalue test cochram < ", alpha1,  sep = "")
      mtext(text1, side = 4)
      text1<-paste( "Frequency of batches with outlying variability=", sum(table(elem.sin.na)),  sep = "")
      mtext(text1, side = 3)


      #total de batches y total de variables: observar que batches son los mas variables para todas las variables consideradas
      batches.variabilidad.encimadelamedia<- c(batches.variabilidad.encimadelamedia, elem.sin.na)


    }

  }


  #total de batches y total de variables
  if (Resampling==T){
    par(mfrow=c(1,1))
    batches.variabilidad.encimadelamedia<-as.vector(na.omit(batches.variabilidad.encimadelamedia))
    #dar un grafico de variabilidad total
    meds1 <- 100*table(batches.variabilidad.encimadelamedia)/(nremuestras*dim(X)[2])
    bmax <- max(100*table(batches.variabilidad.encimadelamedia)/(nremuestras*dim(X)[2]))
    #AQUI HAY UN PROBLEMA CON LAS ETIQUETAS
    #if(dim(meds1) != nlevels(aa$Batches)){
    #levels(aa$Batches)[c(1,2,4,5)]
    labs.batches<-levels(aa$Batches)[as.numeric(names(meds1))]
    bp2 <- barplot(meds1, beside=TRUE,
                   axes=T, xlab="Batches with hight variability", col=rainbow(5)[c(4,1:3,5)],
                   ylab="Frequency (%)", ylim=c(0,100), names.arg=labs.batches)

    #}
    #ningun problema con las etiquetas
    #if(dim(meds1) == nlevels(aa$Batches)){
    #  bp2 <- barplot(meds1, beside=TRUE,
    #                 axes=T, xlab="Batches with hight variability", col=rainbow(5)[c(4,1:3,5)],
    #                 ylab="Frequency (%)", ylim=c(0,100), names.arg=levels(aa$Batches))
    #
    #}
    #for(i in 1:max(as.numeric(names(meds1)))){

    #axis(2, at=seq(0,100,10))
    #axis(2, at=seq(0,max(batches.variabilidad.encimadelamedia),10))
    title("Variabilidad de Batches en totdas las variables")
    text2<-"% veces que superan el 95% de variabilidad media en test de Cochran"
    mtext(text2, side = 3)

    text1<-paste( "Frequency=", sum(table(batches.variabilidad.encimadelamedia)), sep = "")
    mtext(text1, side = 4)

    abline(h = max.perc.var,col="red")
    text(0,11.5,labels = "10%",col="red")
    #uniform test par saber si hay variabilidad en los batches o no
    ks.unif<- ks.test(meds1, punif)
    print(ks.unif)
    #tulip <- c(1,  0.30)
    num.batches<-nlevels(aa$Batches)
    res <- chisq.test(c(meds1), p = rep(1/length(meds1), length(meds1)))
    print("")
    print("---------------------------------------------------")
    print("Chi square test to detect outlyed variable batches: Uniform distribution")
    print(res)

    #plot(0,0)
    #title("% veces que superan el 95% de variabilidad media en test de Cochran")
    #text2<-"% veces que superan el 95% de variabilidad media en test de Cochran"
    #mtext(text2, side = 3)
    #text3<-paste(meds1)
    #mtext(text3, side = 1)

    #legend("topright", legend=c("LOW", "HIGH"), bty="n", fill=c("azure3", "azure"))
    #text(bp, 0, round(medtimerx, 1), cex=1, pos=3)
    #text1<-paste( "% pvalue<0.05=", round(100*cdf0.05,2) , " ",  sep = "")
    #mtext(text1, side = 4)
    #text(20,2, print(meds1))
    print(meds1)
    return(meds1)
  }

}






#############################################################
#SIMULACION: 3 BATCHES Y 3 VARIABLES - DISTRIBUCION NORMAL
##############################################################
#con una simulacion de 3 bathes y 3 variables
#Batches.referencia.simulados <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10)), var1 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var2 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)), var3 = c(rnorm(10,50,4), rnorm(10,50,4), rnorm(10,50,4)))
#Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.001, nremuestras = 10000 )
#Englemann.Hecker.Plot.Algorithm(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat)

#con una simulacion de 5 bathes y 3 variables
#Batches.referencia.simulados <- data.frame(Bat = c(rep("B1",10),rep("B2",10),rep("B3",10),rep("B4",10),rep("B5",10)),
#                                           var1 = c(rnorm(10,55,12), rnorm(10,55,4), rnorm(10,55,4),rnorm(10,55,4),rnorm(10,55,4)),
#                                           var2 = c(rnorm(10,5500,890), rnorm(10,5500,400), rnorm(10,5500,400),rnorm(10,5500,400),rnorm(10,5500,400)),
#                                           var3 = c(rnorm(10,12,7), rnorm(10,12,4), rnorm(10,12,4),rnorm(10,12,4),rnorm(10,12,4)))
#todas las variables
#Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000 )
#solo las 2 primeras componentes pca
#Check.variance.test(X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,Resampling = T,alpha1 = 0.01, nremuestras = 10000,PCA.transform = T )

#analisis de batches y test de homogeneidad de CV, todas las variables sin PCA
#Englemann.Hecker.Plot.Algorithm (X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,PCA.transform = F)

#analisis de batches y test de homogeneidad de CV-con PCA para todas las variables
#Englemann.Hecker.Plot.Algorithm (X=Batches.referencia.simulados[,2:4],Batches=Batches.referencia.simulados$Bat,PCA.transform = T,center.PCA=T, scale.PCA=F)



#resultado:
#batches.variabilidad.encimadelamedia
#1         2         3         4         5         6: lote B6         7         8         9        10
#12.500000 18.250000  8.416667  1.583333  7.416667 23.833333  1.166667 16.500000  2.083333  8.250000


